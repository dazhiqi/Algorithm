import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.awt.*;

public class nothing {
	
		

public static void main(String [] args){
	System.out.println("Hi, hows it goin?");


	}
}
