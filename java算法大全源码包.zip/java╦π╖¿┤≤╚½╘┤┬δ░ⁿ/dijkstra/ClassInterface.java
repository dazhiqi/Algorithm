/* ClassInterface.java */

public interface ClassInterface {
	public  double Cost();
	}
